#ifndef _TVG_GL_SHADER_H_
#define _TVG_GL_SHADER_H_

#include "tvgCommon.h"

enum GlAttrib
{
  Location = 0,
};

class GlShader
{
public:
    void    createShader(const char* vertSrc, const char* fragSrc);
    void    loadShader();
    int32_t registerProperty(const char* propertyName);
    void    loadProperty(int32_t propertyId, float r, float g, float b, float a);
private:
    uint32_t complileShader(uint32_t type, char* shaderSrc);
    
    uint32_t mColorProgram;
    static uint32_t mCurrentProgram;
};



#endif /* _TVG_GL_SHADER_H_ */
