#include "tvgGlShaderSrc.h"

const char* COLOR_VERT_SHADER =
"attribute highp vec4 aPosition;				\n"
"uniform highp vec4 ucolor;						\n"
"varying highp vec4 vcolor;						\n"
"varying highp float vOpacity;					\n"
"void main()									\n"
"{												\n"
"   gl_Position = vec4(aPosition.xy, 0.0, 1.0);	\n"
"   vcolor = ucolor;							\n"
"   vOpacity = aPosition.z;						\n"
"}												\n";
												
const char* COLOR_FRAG_SHADER =
"varying highp vec4 vcolor;								\n"
"varying highp float vOpacity;							\n"
"void main()											\n"
"{														\n"
"  gl_FragColor = vec4(vcolor.xyz, vcolor.w*vOpacity);	\n"
"}														\n";

