#ifndef _TVG_GL_SHADERSRC_H_
#define _TVG_GL_SHADERSRC_H_

extern const char* COLOR_VERT_SHADER;
extern const char* COLOR_FRAG_SHADER;

#endif /* _TVG_GL_SHADERSRC_H_ */
