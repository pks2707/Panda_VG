#include "tvgGlCommon.h"
#include <GLES2/gl2.h>

#include <iostream>

uint32_t GlShader::mCurrentProgram = 0;

void GlShader::createShader(const char* vertSrc, const char* fragSrc)
{
	GLuint vShader = complileShader(GL_VERTEX_SHADER, const_cast<char*>(vertSrc));
	GLuint fShader = complileShader(GL_FRAGMENT_SHADER, const_cast<char*>(fragSrc));
	GLint linked;

	// Create the program object
	uint32_t progObj = glCreateProgram();
	assert(progObj);

	glAttachShader(progObj, vShader);
	glAttachShader(progObj, fShader);

	glBindAttribLocation(progObj, GlAttrib::Location, "aPosition");

	// Link the program
	glLinkProgram(progObj);

	// Check the link status
	glGetProgramiv(progObj, GL_LINK_STATUS, &linked);

	if (!linked)
	{
		GLint infoLen = 0;
		glGetProgramiv(progObj, GL_INFO_LOG_LENGTH, &infoLen);
		if (infoLen > 1)
		{
			char* infoLog = new char[infoLen];
			glGetProgramInfoLog(progObj, infoLen, NULL, infoLog);
			std::cout << "Error linking shader: " << infoLog << std::endl;
			delete[] infoLog;

		}
		glDeleteProgram(progObj);
		progObj = 0;
		assert(0);
	}
	mColorProgram = progObj;
}

void GlShader::loadShader()
{
	glUseProgram(mColorProgram);
}

int32_t GlShader::registerProperty(const char* propertyName)
{
	return glGetUniformLocation(mColorProgram, propertyName);
}

void GlShader::loadProperty(int32_t propertyId, float r, float g, float b, float a)
{
	glUniform4f(propertyId, r, g, b, a);
}

uint32_t GlShader::complileShader(uint32_t type, char* shaderSrc)
{
	GLuint shader;
	GLint compiled;

	// Create the shader object
	shader = glCreateShader(type);
	assert(shader);
	
	// Load the shader source
	glShaderSource(shader, 1, &shaderSrc, NULL);

	// Compile the shader
	glCompileShader(shader);

	// Check the compile status
	glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);

	if (!compiled)
	{
		GLint infoLen = 0;

		glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &infoLen);

		if (infoLen > 1)
		{
			char* infoLog = new char[infoLen];
			glGetShaderInfoLog(shader, infoLen, NULL, infoLog);
			std::cout << "Error compiling shader: " << infoLog << std::endl;
			delete[] infoLog;
		}
		glDeleteShader(shader);
		assert(0);
	}

	return shader;
}

