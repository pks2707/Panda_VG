#ifndef _AppFW_EGL_INTERFACE_H_
#define _AppFW_EGL_INTERFACE_H_

#include "Vector2.h"
#include "Vector4.h"

#include <GLES2/gl2.h>
#include <EGL/egl.h>
#include <EGL/eglext.h>

namespace AppFW
{
#define PRINT_EGL_ERROR(str) LOGE("%s. Egl Error : %d.", str, eglGetError())
#define PRINT_GL_ERROR(str) LOGE("%s. GL Error : %d.", str, glGetError())

  enum eAttribute
  {
    ATTRIB_LOCATION = 0,
  };

	class EglInterface
	{
	public:

		void Initialize(Vector2 windowSize, EGLNativeDisplayType nativeDisplay, EGLNativeWindowType nativeWindow);
		void SetBackgroundColor(float r, float g, float b, float a);
		void StartRender();
		void FinishRender();

		static EglInterface& Instance();

	private:
		static EglInterface* mInstance;

		EglInterface();
		EGLint GetContextRenderableType(EGLDisplay eglDisplay);

		EGLNativeDisplayType mNativeDisplay;
		EGLNativeWindowType  mNativeWindow;

		EGLDisplay  mEglDisplay;
		EGLContext  mEglContext;
		EGLSurface  mEglSurface;

		Vector2		mWindowSize;
		ColorF		mWindowBgColor;
	};
}

#endif //_AppFW_EGL_INTERFACE_H_
