#ifndef _AppFW_VGACTOR_H_
#define _AppFW_VGACTOR_H_

#include "Actor.h"
#include "Vector4.h"

namespace AppFW
{
    class VGActor : public Actor
    {
    public:
        VGActor();
        ~VGActor() = default;

        VGActor(const VGActor& actor) = default;
        VGActor(VGActor&& actor) = default;

        VGActor& operator=(const VGActor& actor) = default;
        VGActor& operator= (VGActor&& actor) = default;

        void AddRect(float radius);
        void AddEllipse();
        void SetFill(ColorI color);
        void SetStroke(ColorI color, uint32_t width);
        void Upload();

    private:
    };
    typedef std::shared_ptr<VGActor> SP_VGActor;
}

#endif //_AppFW_VGACTOR_H_
