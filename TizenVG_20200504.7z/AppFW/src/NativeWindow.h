#ifndef _AppFW_NATIVEWINDOW_H_
#define _AppFW_NATIVEWINDOW_H_

#include "Vector2.h"
#include "Utility.h"
#include "Actor.h"

#include <EGL/egl.h>
#include <vector>
#include <string>

typedef void (P_CALLBACK *RV_1V) (void *);
typedef void (P_CALLBACK *RV_1V_1C_2I) (void *, unsigned char, int, int);
typedef void (P_CALLBACK *RV_1F) (void *, float);

typedef RV_1V RenderCallback;
typedef RV_1V ShutdownCallback;
typedef RV_1V_1C_2I KeyCallback;
typedef RV_1F UpdateCallback;

namespace AppFW
{
class NativeWindow
{
public:
	NativeWindow();
	virtual ~NativeWindow() = default;

	NativeWindow(const NativeWindow &win) = default;
	NativeWindow(NativeWindow &&win) = default;

	NativeWindow &operator=(const NativeWindow &win) = default;
	NativeWindow &operator=(NativeWindow &&win) = default;

	void Initialize(std::string title, uint32_t windowWidth, uint32_t windowHeight);
	void Start();
	void Add(SP_Actor actor);
	void Remove(SP_Actor actor);
	void Render();

	void SetWindowTitle(std::string strWindowTitle);
	std::string WindowTitle() const;
	void SetWindowSize(const Vector2 windowSize);
	Vector2 WindowSize() const;
	uint32_t WindowWidth() const;
	uint32_t WindowHeight() const;

	void SetRenderCallback(RenderCallback cb);

	void SetUpdateRenderCallback(UpdateCallback cb);
	void SetKeyCallback(KeyCallback cb);
	void SetShutDownCallback(ShutdownCallback cb);
	void SetApplicationData(void *data);

	virtual bool HandleEvent() = 0;
	virtual EGLNativeWindowType GetWindowHandle() = 0;
	virtual EGLNativeDisplayType GetWindowContext() = 0;

private:
	virtual void CreateNativeWindow() = 0;

protected:
	void *mAppData;
	std::vector<SP_Actor> mActorList;

	/// Callbacks
	RenderCallback mRenderCb;
	UpdateCallback mUpdateCb;
	KeyCallback mKeyCb;
	ShutdownCallback mShutdownCb;

private:
	std::string mWindowTitle;
	Vector2 mWindowSize;
};
} // namespace AppFW

#endif //_AppFW_NATIVEWINDOW_H_
