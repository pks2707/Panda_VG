#include "Utility.h"

#if defined(_WIN32) || defined(_WIN64)
#include <Windows.h>
#else
#include <sys/time.h>
#endif

namespace AppFW
{
	Logger::LogLevel Logger::mLevel = Logger::LogLevel::ERROR;

	uint64_t Utility::GetTime()
	{
#ifdef _WIN32
		return GetTickCount();
#else
	uint64_t ts;
	struct timeval tv;
	gettimeofday(&tv, nullptr);
	ts = ((uint64_t)tv.tv_sec * 1000 * 1000) +  (uint64_t)tv.tv_usec;
	return ts;
#endif
	}

}	