#ifndef _AppFW_WINDOW_MANAGER_H_
#define _AppFW_WINDOW_MANAGER_H_

#ifdef _WIN32
#include "NativeWindow_Win.h"
#else
#include "NativeWindow_Unix.h"
#endif
#include "Logger.h"

namespace AppFW
{
	class WindowManager
	{
	public:
		static NativeWindow& Instance()
		{
			if (!mInstance) {
				try
				{
#ifdef _WIN32
					mInstance = new NativeWindow_Win();
#else
					mInstance = new NativeWindow_Unix();
#endif
				}
				catch (std::bad_alloc & exception)
				{
					LOGE("bad_alloc detected: %s", exception.what());
				}
			}
			return *mInstance;
		}
	private:
		WindowManager();

		static NativeWindow*	mInstance;
	};	
}
#endif //_AppFW_WINDOW_MANAGER_H_