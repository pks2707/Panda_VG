#include "tvgGlCommon.h"

#include <exception>

#define ADD_FAN_VERTICES(i, indices) \
    indices.push_back(0);            \
    indices.push_back(i - 1);        \
    indices.push_back(i)

#define ADD_QUAD_VERTICES(i, indices) \
    indices.push_back(i);             \
    indices.push_back(i + 1);         \
    indices.push_back(i + 2);         \
    indices.push_back(i + 1);         \
    indices.push_back(i + 3);         \
    indices.push_back(i + 2);         \
    i += 4

static Point _normalizePoint(Point &pt, float viewWd, float viewHt)
{
    Point p;
    p.x = (pt.x * 2.0f / viewWd) - 1.0f;
    p.y = -1.0f * ((pt.y * 2.0f / viewHt) - 1.0f);
    return p;
}

static void _addGeometryPoint(Geometry &geometry, Point &pt, float viewWd, float viewHt, float opacity)
{
    VertexProp tv = {_normalizePoint(pt, viewWd, viewHt), opacity};
    geometry.vertices.push_back(tv);
}

static Point _getNormal(Point &p1, Point &p2)
{
    Point normal = p1 - p2;
    normal.normalize();
    return Point(-normal.y, normal.x);
}

static float _dotProduct(Point &p1, Point &p2)
{
    return (p1.x * p2.x + p1.y * p2.y);
}

static Point _extendEdge(Point &pt, Point &normal, float scalar)
{
    Point tmp = (normal * scalar);
    return (pt + tmp);
}

static void _addPoint(GlShape &sdata, Point &pt)
{
    sdata.pts.push_back(pt);
}

static void _addTriangleFanIndices(uint32_t &curPt, std::vector<uint32_t> &indices)
{
    indices.push_back(0);
    indices.push_back(curPt - 1);
    indices.push_back(curPt);
}

static void _addQuadIndices(uint32_t &curPt, std::vector<uint32_t> &indices)
{
    indices.push_back(curPt);
    indices.push_back(curPt + 1);
    indices.push_back(curPt + 2);
    indices.push_back(curPt + 1);
    indices.push_back(curPt + 3);
    indices.push_back(curPt + 2);
    curPt += 4;
}

static bool _isBezierFlat(Point &p1, Point &c1, Point &c2, Point &p2)
{
    Point diff1 = (c1 * 3.0f) - (p1 * 2.0f) - p2;
    Point diff2 = (c2 * 3.0f) - (p2 * 2.0f) - p1;

    diff1.mod();
    diff2.mod();
    if (diff1.x < diff2.x)
        diff1.x = diff2.x;
    if (diff1.y < diff2.y)
        diff1.y = diff2.y;

    if (diff1.x + diff1.y <= 0.5f)
        return true;
    return false;
}

static void _decomposeCubicCurve(GlShape &sdata, Point &pt1, Point &cpt1, Point &cpt2, Point &pt2)
{
    if (_isBezierFlat(pt1, cpt1, cpt2, pt2))
    {
        _addPoint(sdata, pt2);
        return;
    }
    Point p12 = (pt1 + cpt1) * 0.5f;
    Point p23 = (cpt1 + cpt2) * 0.5f;
    Point p34 = (cpt2 + pt2) * 0.5f;

    Point p123 = (p12 + p23) * 0.5f;
    Point p234 = (p23 + p34) * 0.5f;

    Point p1234 = (p123 + p234) * 0.5f;

    _decomposeCubicCurve(sdata, pt1, p12, p123, p1234);
    _decomposeCubicCurve(sdata, p1234, p234, p34, pt2);
}

void shapeReset(GlShape &sdata)
{
    sdata.pts.clear();
    sdata.fillGeometry.vertices.clear();
    sdata.fillGeometry.indices.clear();
    sdata.strokeGeometry.vertices.clear();
    sdata.strokeGeometry.indices.clear();
}

bool glDecomposeOutline(const Shape &shape, GlShape &sdata)
{
    const PathCommand *cmds = nullptr;
    auto cmdCnt = shape.pathCommands(&cmds);

    Point *pts = nullptr;
    auto ptsCnt = shape.pathCoords(const_cast<const Point **>(&pts));

    //No actual shape data
    if (cmdCnt == 0 || ptsCnt == 0)
        return false;

    for (size_t i = 0; i < cmdCnt; ++i)
    {
        switch (*(cmds + i))
        {
            case PathCommand::Close:
            {
                if ( sdata.pts.size() > 0 &&
                (sdata.pts[0].orgPt != sdata.pts.back().orgPt) )
                {
                    sdata.pts.push_back(sdata.pts[0].orgPt);
                }
                break;
            }
            case PathCommand::MoveTo:
            case PathCommand::LineTo:
            {
                _addPoint(sdata, pts[0]);
                pts++;
                break;
            }
            case PathCommand::CubicTo:
            {
                _decomposeCubicCurve(sdata, sdata.pts.back().orgPt, pts[0], pts[1], pts[2]);
                pts += 3;
                break;
            }
        }
    }
    return true;
}

bool glGenerateAAPoints(const Shape &shape, GlShape &sdata, float strokeWd, RenderUpdateFlag flag)
{
    std::vector<PointNormal> normalInfo;
    // constexpr float aaLen = 1.0f;
    constexpr float blurDir = -1.0f;

    size_t nPoints = sdata.pts.size();
    if (nPoints < 2)
    {
        return false;
    }

    normalInfo.resize(nPoints);

    size_t fPoint = 0;
    size_t sPoint = 1;
    for (size_t i = 0; i < nPoints - 1; ++i)
    {
        fPoint = i;
        sPoint = i + 1;
        if (sPoint == nPoints - 1)
            sPoint = 0;

        Point normal = _getNormal(sdata.pts[fPoint].orgPt, sdata.pts[sPoint].orgPt);

        normalInfo[fPoint].normal1 = normal;
        normalInfo[sPoint].normal2 = normal;
    }
    normalInfo[nPoints - 1].normal1 = normalInfo[0].normal1;
    normalInfo[nPoints - 1].normal2 = normalInfo[0].normal2;

    for (uint32_t i = 0; i < nPoints; ++i)
    {
        normalInfo[i].normalF = normalInfo[i].normal1 + normalInfo[i].normal2;
        normalInfo[i].normalF.normalize();

        float angle = _dotProduct(normalInfo[i].normal2, normalInfo[i].normalF);
        if (angle != 0)
            normalInfo[i].normalF = normalInfo[i].normalF / angle;
        else
            normalInfo[i].normalF = Point(0, 0);

        if (flag & RenderUpdateFlag::Fill)
        {
            Point temp = _extendEdge(sdata.pts[i].orgPt, normalInfo[i].normalF, blurDir * strokeWd);
            if ( (flag & RenderUpdateFlag::Stroke) == 0)
                temp = sdata.pts[i].orgPt;
            sdata.pts[i].fillOuterBlur = temp;
            sdata.pts[i].fillOuter = _extendEdge(sdata.pts[i].fillOuterBlur, normalInfo[i].normalF, blurDir);
        }
        if (flag & RenderUpdateFlag::Stroke)
        {
            sdata.pts[i].strokeOuterBlur = sdata.pts[i].orgPt;
            sdata.pts[i].strokeOuter = _extendEdge(sdata.pts[i].strokeOuterBlur, normalInfo[i].normalF, blurDir);
            sdata.pts[i].strokeInner = _extendEdge(sdata.pts[i].strokeOuter, normalInfo[i].normalF, blurDir * strokeWd);
            sdata.pts[i].strokeInnerBlur = _extendEdge(sdata.pts[i].strokeInner, normalInfo[i].normalF, blurDir);
        }
    }
    return true;
}

bool glTesselate(const Shape &shape, GlShape &sdata, RenderUpdateFlag flag)
{
    constexpr float opaque = 1.0f;
    constexpr float transparent = 0.0f;
    printf("\n [%s:%d] => glTesselate flag : %d", __FILE__, __LINE__, flag);
    fflush(stdout);
    try
    {
        if (flag & RenderUpdateFlag::Fill)
        {
            uint32_t i = 0;
            for (size_t pt = 0; pt < sdata.pts.size(); ++pt)
            {
                _addGeometryPoint(sdata.fillGeometry, sdata.pts[pt].fillOuter, sdata.viewWd, sdata.viewHt, opaque);
                if (i > 1)
                {
                    // ADD_FAN_VERTICES(i, sdata.fillGeometry.indices);
                    _addTriangleFanIndices(i, sdata.fillGeometry.indices);
                }
                ++i;
            }
            for (size_t pt = 1; pt < sdata.pts.size(); ++pt)
            {
                _addGeometryPoint(sdata.fillGeometry, sdata.pts[pt - 1].fillOuterBlur, sdata.viewWd, sdata.viewHt, transparent);
                _addGeometryPoint(sdata.fillGeometry, sdata.pts[pt - 1].fillOuter, sdata.viewWd, sdata.viewHt, opaque);
                _addGeometryPoint(sdata.fillGeometry, sdata.pts[pt].fillOuterBlur, sdata.viewWd, sdata.viewHt, transparent);
                _addGeometryPoint(sdata.fillGeometry, sdata.pts[pt].fillOuter, sdata.viewWd, sdata.viewHt, opaque);
                // ADD_QUAD_VERTICES(i, sdata.fillGeometry.indices);
                _addQuadIndices(i, sdata.fillGeometry.indices);
            }
    printf("\n [%s:%d] => glTesselate vertices : %lu, indices : %lu", __FILE__, __LINE__, sdata.fillGeometry.vertices.size(), sdata.fillGeometry.indices.size());
    fflush(stdout);
        }
        if (flag & RenderUpdateFlag::Stroke)
        {
            uint32_t i = 0;
            for (size_t pt = 1; pt < sdata.pts.size(); ++pt)
            {
                _addGeometryPoint(sdata.strokeGeometry, sdata.pts[pt - 1].strokeOuter, sdata.viewWd, sdata.viewHt, opaque);
                _addGeometryPoint(sdata.strokeGeometry, sdata.pts[pt - 1].strokeInner, sdata.viewWd, sdata.viewHt, opaque);
                _addGeometryPoint(sdata.strokeGeometry, sdata.pts[pt].strokeOuter, sdata.viewWd, sdata.viewHt, opaque);
                _addGeometryPoint(sdata.strokeGeometry, sdata.pts[pt].strokeInner, sdata.viewWd, sdata.viewHt, opaque);
                //ADD_QUAD_VERTICES(i, sdata.strokeGeometry.indices);
                _addQuadIndices(i, sdata.strokeGeometry.indices);
            }
            for (size_t pt = 1; pt < sdata.pts.size(); ++pt)
            {
                _addGeometryPoint(sdata.strokeGeometry, sdata.pts[pt - 1].strokeOuterBlur, sdata.viewWd, sdata.viewHt, transparent);
                _addGeometryPoint(sdata.strokeGeometry, sdata.pts[pt - 1].strokeOuter, sdata.viewWd, sdata.viewHt, opaque);
                _addGeometryPoint(sdata.strokeGeometry, sdata.pts[pt].strokeOuterBlur, sdata.viewWd, sdata.viewHt, transparent);
                _addGeometryPoint(sdata.strokeGeometry, sdata.pts[pt].strokeOuter, sdata.viewWd, sdata.viewHt, opaque);
                //ADD_QUAD_VERTICES(i, sdata.strokeGeometry.indices);
                _addQuadIndices(i, sdata.strokeGeometry.indices);
            }
            for (size_t pt = 1; pt < sdata.pts.size(); ++pt)
            {
                _addGeometryPoint(sdata.strokeGeometry, sdata.pts[pt - 1].strokeInner, sdata.viewWd, sdata.viewHt, opaque);
                _addGeometryPoint(sdata.strokeGeometry, sdata.pts[pt - 1].strokeInnerBlur, sdata.viewWd, sdata.viewHt, transparent);
                _addGeometryPoint(sdata.strokeGeometry, sdata.pts[pt].strokeInner, sdata.viewWd, sdata.viewHt, opaque);
                _addGeometryPoint(sdata.strokeGeometry, sdata.pts[pt].strokeInnerBlur, sdata.viewWd, sdata.viewHt, transparent);
                //ADD_QUAD_VERTICES(i, sdata.strokeGeometry.indices);
                _addQuadIndices(i, sdata.strokeGeometry.indices);
            }
    printf("\n [%s:%d] => glTesselate vertices : %lu, indices : %lu", __FILE__, __LINE__, sdata.strokeGeometry.vertices.size(), sdata.strokeGeometry.indices.size());
    fflush(stdout);
        }
    }
    catch (std::exception &e)
    {
        std::cerr << "exception caught: " << e.what() << '\n';
    }
    sdata.pts.clear();
    return true;
}