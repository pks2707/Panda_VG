#ifndef _TVG_GL_COMMON_H_
#define _TVG_GL_COMMON_H_

#include "tizenvg.h"
#include "tvgCommon.h"

#include <vector>

enum GlAttrib
{
  Location = 0,
};

struct GlPoint
{
    Point orgPt;
    Point fillOuterBlur;
    Point fillOuter;
    Point strokeOuterBlur;
    Point strokeOuter;
    Point strokeInnerBlur;
    Point strokeInner;

    GlPoint(Point pt) 
        :orgPt(pt),
        fillOuterBlur(pt),
        fillOuter(pt),
        strokeOuterBlur(pt),
        strokeOuter(pt),
        strokeInnerBlur(pt),
        strokeInner(pt)
    {
    }
};

struct PointNormal
{
    Point normal1;
    Point normal2;
    Point normalF;
};

struct VertexProp
{
   Point point;
   float opacity = 0.0f;
};

struct Geometry
{
    std::vector<VertexProp>   vertices;
    std::vector<uint32_t>     indices;

    Geometry() {
        vertices.clear();
        indices.clear();
    }
};

struct GlShape
{
  float                     viewWd;
  float                     viewHt;
  uint32_t                  progObject;
  std::vector<GlPoint>      pts;
  Geometry                  fillGeometry;
  Geometry                  strokeGeometry;
};

extern const char* COLOR_VERT_SHADER;
extern const char* COLOR_FRAG_SHADER;

void shapeReset(GlShape& sdata);
uint32_t createShader(const char* vertSrc, const char* fragSrc);
void loadShader(uint32_t program);
void loadUniform(int32_t uniformID, float r, float g, float b, float a);
int32_t getUniformID(uint32_t program, const char* uniformName);
uint32_t generateVertexAttribute();
void UpdateBufferData(uint32_t bufferId, Geometry& geomtry);
void drawVertices(Geometry& geomtry);

bool glDecomposeOutline(const Shape& shape, GlShape& sdata);
bool glGenerateAAPoints(const Shape& shape, GlShape& sdata, float strokeWd, RenderUpdateFlag flag);
bool glTesselate(const Shape& shape, GlShape& sdata, RenderUpdateFlag flag);

#endif /* _TVG_GL_Shader_H_ */