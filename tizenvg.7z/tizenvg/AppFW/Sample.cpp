#include "Application.h"
#include "WindowManager.h"
#include "VGActor.h"

using namespace AppFW;

class VGActorSample : public Application
{
    SP_VGActor actor1;

public:
    void OnCreate() override
    {
        actor1 = std::make_shared<VGActor>();
        actor1->SetPosition(10, 10);
        actor1->SetSize(800, 600);
        actor1->AddRect(0.0f);
        actor1->SetFillColor(ColorI(255, 0, 0, 255));
        actor1->Upload();
        WindowManager::Instance().Add(actor1);
    }

    
};

int main()
{
    VGActorSample app;
    app.SetBackgroundColor(0.2f, 0.2f, 0.2f, 1.0f);
    app.Run();
    return 0;
}
