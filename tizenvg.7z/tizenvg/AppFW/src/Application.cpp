#include "Application.h"
#include "WindowManager.h"
#include "EglInterface.h"
#include "Utility.h"

namespace AppFW
{
	Window* WindowManager::mInstance = nullptr;

	Application::Application(std::string windowTitle, uint32_t windowWd, uint32_t windowHt)
	:mShutDown(false)
	{
		Window& window = WindowManager::Instance();
		window.Initialize(windowTitle, windowWd, windowHt);
		window.SetRenderCallback(Application::RenderCb);
		window.SetApplicationData(this);
		EglInterface::Instance().Initialize(window.WindowSize(),
											static_cast<EGLNativeDisplayType>(window.GetWindowContext()), 
											static_cast<EGLNativeWindowType>(window.GetWindowHandle()));

	}

  void Application::SetBackgroundColor(float red, float green, float blue, float alpha)
  {
    EglInterface::Instance().SetBackgroundColor(red, green, blue, alpha);
  }

	void Application::Run()
	{
		auto lastTime = Utility::GetTime();

    OnCreate();
    WindowManager::Instance().Start();

		while (!mShutDown)
		{
			DWORD curTime = GetTickCount();
			float deltaTime = (float)(curTime - lastTime) / 1000.0f;
			lastTime = curTime;

			WindowManager::Instance().HandleEvent();
      OnUpdate(deltaTime);
		}
    OnExit();
	}

  void Application::Exit()
  {
    mShutDown = true;
  }

  void Application::OnCreate()
  {
  }

	void Application::OnUpdate(float deltaTime)
	{
	}

	void Application::Render()
	{
		EglInterface::Instance().StartRender();
		WindowManager::Instance().Render();
		EglInterface::Instance().FinishRender();
	}

	void Application::OnExit()
	{
	}

	void Application::RenderCb(void * data)
	{
		Application* pThis = reinterpret_cast<Application*>(data);
		pThis->Render();
	}
}