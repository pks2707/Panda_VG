#ifndef _AppFW_ACTOR_H_
#define _AppFW_ACTOR_H_

#include "Vector2.h"

#include <vector>
#include <memory>

namespace AppFW
{
    class Renderer;

    class Actor : std::enable_shared_from_this<Actor>
    {
    public:
        Actor();
        ~Actor() = default;

        Actor(const Actor& actor) = default;
        Actor(Actor&& actor) = default;

        Actor& operator=(const Actor& actor) = default;
        Actor& operator= (Actor&& actor) = default;

        void SetSize(float width, float height);
        Point GetSize();

        void SetPosition(float x, float y);
        SizeF GetPosition();

        void SetParent(std::shared_ptr<Actor> Actor);
        void Add(std::shared_ptr<Actor> actor);
        void Remove(std::shared_ptr<Actor> actor);

        void AddRenderer(std::shared_ptr<Renderer> renderer);
        std::shared_ptr<Renderer> GetRendererAt(uint32_t index);
        void RemoveRendererAt(uint32_t index);

        uint64_t GetID() { return mActorID; }
        uint32_t GetChildrenCount() { return mChildActors.size(); }
        std::shared_ptr<Actor> GetChildrenAt(uint32_t index) { return mChildActors[index]; }

        virtual void OnCreate();
        virtual void OnUpdate();
        void Render();

    protected:
        std::shared_ptr<Actor> GetSharedThis()
        {
            return shared_from_this();
        }
    private:
        uint64_t    mActorID;
        SizeF       mSize;
        Point       mPosition;

        std::shared_ptr<Actor> mParent;
        std::vector<std::shared_ptr<Actor>> mChildActors;
        std::vector<std::shared_ptr<Renderer>> mRenderTasks;

        static uint64_t s_ActorIDCountetr;
    };
    typedef std::shared_ptr<Actor> SP_Actor;
}

#endif //_AppFW_ACTOR_H_
