#ifndef _AppFW_LOGGER_H_
#define _AppFW_LOGGER_H_

#include <iostream>
#include <assert.h>

namespace AppFW
{
	class Logger
	{
	public:
		enum LogLevel
		{
			None = 0x0,
			Error = 0x1,
			Debug = 0x3,
			Info = 0x7,
		};

		static void Initialize(LogLevel level = LogLevel::Error)
		{
			mLevel = level;
		}

		static bool CheckLevel(LogLevel l)
		{
			if ((mLevel & l) == 0)
				return false;
			return true;
		}

	private:
		static LogLevel mLevel;
	};
}

#define LOG(format, ...) printf(format, __VA_ARGS__);
#define LOGD(format, ...) if(AppFW::Logger::CheckLevel(AppFW::Logger::LogLevel::Debug)) \
							printf("[%s:%d] => " format, __FUNCTION__, __LINE__, __VA_ARGS__); \
							printf("\n")

#define LOGE(format, ...) if(AppFW::Logger::CheckLevel(AppFW::Logger::LogLevel::Error)) \
							printf("[%s:%d] => " format, __FUNCTION__, __LINE__, __VA_ARGS__); \
							printf("\n")

#define ASSERT(x) if((x)== 0) assert(0)

#endif //_TVG_LOGGER_H_