#ifndef _AppFW_WINDOW_WIN_H_
#define _AppFW_WINDOW_WIN_H_

#include "Window.h"

#include <Windows.h>

namespace AppFW
{
	class Window_Win : public Window
	{
	public:
		Window_Win();
		~Window_Win() = default;

		Window_Win(const Window_Win& win) = default;
		Window_Win(Window_Win&& win) = default;

		Window_Win& operator=(const Window_Win& win) = default;
		Window_Win& operator=(Window_Win&& win) = default;

		void HandleEvent();
		void* GetWindowHandle();
		void* GetWindowContext();

		static LRESULT WINAPI WindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

	private:
		virtual void CreateNativeWindow();

		HWND mWindowHandle;
	};
}

#endif //_AppFW_WINDOW_WIN_H_
