#include "Utility.h"

#include <Windows.h>

namespace AppFW
{
	Logger::LogLevel Logger::mLevel = Logger::LogLevel::Error;

	uint64_t Utility::GetTime()
	{
#ifdef _WIN32
		return GetTickCount();
#endif
	}

}	