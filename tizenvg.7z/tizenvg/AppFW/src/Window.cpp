#include "Window.h"

namespace AppFW
{
	Window::Window()
	:mAppData(nullptr),
		mWindowTitle(""),
		mWindowSize(800.0f, 600.0f),
		mRenderCb(nullptr),
		mUpdateCb(nullptr),
		mKeyCb(nullptr),
		mShutdownCb(nullptr)
	{
	}

	void Window::Initialize(std::string title, uint32_t windowWidth, uint32_t windowHeight)
	{
		SetWindowTitle(title);
		SetWindowSize(Vector2((float)windowWidth, (float)windowHeight));
		CreateNativeWindow();
	}

  void Window::Start()
  {
    for (auto actor : mActorList)
    {
      actor->OnCreate();
    }
  }

  void Window::Add(SP_Actor actor)
  {
    mActorList.push_back(actor);
  }

  void Window::Remove(SP_Actor actor)
  {
    uint32_t index = 0;
    for (auto tempActor : mActorList)
    {
      if (tempActor->GetID() == actor->GetID())
      {
        break;
      }
      ++index;
    }
    mActorList.erase(mActorList.begin() + index);
  }

  void Window::Render()
  {
    for (auto actor : mActorList)
    {
        actor->Render();
    }
  }

	void Window::SetWindowTitle(std::string strWindowTitle)
	{
		mWindowTitle = strWindowTitle;
	}

	std::string Window::WindowTitle() const
	{
		return mWindowTitle;
	}

	void Window::SetWindowSize(const Vector2 windowSize)
	{
		mWindowSize = windowSize;
	}

	Vector2 Window::WindowSize() const
	{
		return mWindowSize;
	}

	uint32_t Window::WindowWidth() const
	{
		return static_cast<uint32_t>(mWindowSize.Width);
	}

	uint32_t Window::WindowHeight() const
	{
		return static_cast<uint32_t>(mWindowSize.Height);
	}

	void Window::SetRenderCallback(RenderCallback cb)
	{
		mRenderCb = cb;
	}

	void Window::SetUpdateRenderCallback(UpdateCallback cb)
	{
		mUpdateCb = cb;
	}

	void Window::SetKeyCallback(KeyCallback cb)
	{
		mKeyCb = cb;
	}

	void Window::SetShutDownCallback(ShutdownCallback cb)
	{
		mShutdownCb = cb;
	}

	void Window::SetApplicationData(void * data)
	{
		mAppData = data;
	}
}
