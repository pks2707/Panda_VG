#include "VGActor.h"
#include "TVGRenderer.h"

#include <memory>

namespace AppFW
{
    VGActor::VGActor()
    {
        SP_TVGRenderer renderer = std::make_shared<TVGRenderer>();
        AddRenderer(renderer);
    }


    void VGActor::AddRect(float radius)
    {
        SP_TVGRenderer renderer = std::dynamic_pointer_cast<TVGRenderer>(GetRendererAt(0));
        renderer->AddRect(GetPosition().X, GetPosition().Y, GetSize().Width, GetSize().Height, radius);
    }

    void VGActor::SetFillColor(ColorI color)
    {
        SP_TVGRenderer renderer = std::dynamic_pointer_cast<TVGRenderer>(GetRendererAt(0));
        renderer->SetFillColor(color);
    }

    void VGActor::Upload()
    {
        SP_TVGRenderer renderer = std::dynamic_pointer_cast<TVGRenderer>(GetRendererAt(0));
        renderer->FinishShape();
    }
}
