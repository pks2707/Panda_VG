#ifndef _AppFW_TVGRENDERER_H_
#define _AppFW_TVGRENDERER_H_

#include "Renderer.h"
#include "Vector4.h"
#include "tizenvg.h"

#include <memory>

namespace AppFW
{
    enum class ShapeType
    {
        None = 0,
        Rectangle = 1,
    };
    struct Shape
    {
        Shape(ShapeType type = ShapeType::None) :shapeType(type) {}

        ShapeType shapeType;
    };

    struct RectShape : public Shape
    {
        RectShape(float x = 0.0f, float y = 0.0f, float w = 0.0f, float h = 0.0f, float r = 0.0f)
            : Shape(ShapeType::Rectangle),
            mx(x),
            my(y),
            mw(w),
            mh(h),
            mr(r)
        {
        }

        float mx;
        float my;
        float mw;
        float mh;
        float mr;
    };

    class TVGRenderer : public Renderer
    {
    public:
        TVGRenderer();
        ~TVGRenderer() = default;

        TVGRenderer(const TVGRenderer& renderer) = default;
        TVGRenderer(TVGRenderer&& renderer) = default;
    
        TVGRenderer& operator= (const TVGRenderer& renderer) = default;
        TVGRenderer& operator= (TVGRenderer && renderer) = default;

        void AddRect(float x, float y, float w, float h, float radius);
        void SetFillColor(ColorI color);
        void FinishShape();
        void Render() override;

    private:
        static bool     mIsInitialized;
        ColorI          mColor;
        Shape*          mShape;
        std::unique_ptr<tvg::GlCanvas> mCanvas = nullptr;
    };

    typedef std::shared_ptr<TVGRenderer> SP_TVGRenderer;

}

#endif //_AppFW_TVGRENDERER_H_
