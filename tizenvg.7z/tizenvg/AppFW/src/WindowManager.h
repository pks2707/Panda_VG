#ifndef _AppFW_WINDOW_MANAGER_H_
#define _AppFW_WINDOW_MANAGER_H_

#ifdef _WIN32
#include "Window_Win.h"
#else
#endif
#include "Logger.h"

namespace AppFW
{
	class WindowManager
	{
	public:
		static Window& Instance()
		{
			if (!mInstance) {
				try
				{
#ifdef _WIN32
					mInstance = new Window_Win();
#else
#endif
				}
				catch (std::bad_alloc & exception)
				{
					LOGE("bad_alloc detected: %s", exception.what());
				}
			}
			return *mInstance;
		}
	private:
		WindowManager();

		static Window*	mInstance;
	};	
}
#endif //_AppFW_WINDOW_MANAGER_H_