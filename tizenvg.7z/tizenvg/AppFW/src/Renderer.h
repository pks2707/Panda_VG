#ifndef _AppFW_RENDERER_H_
#define _AppFW_RENDERER_H_

#include <memory>

namespace AppFW
{
  class Renderer
  {
  public:
    Renderer() = default;
    ~Renderer() = default;

    Renderer(const Renderer& renderer) = default;
    Renderer(Renderer&& renderer) = default;

    Renderer& operator=(const Renderer& renderer) = default;
    Renderer& operator=(Renderer&& renderer) = default;

    virtual void Render();

  private:
  };
  typedef std::shared_ptr<Renderer> SP_Renderer;
}

#endif //_AppFW_RENDERER_H_

