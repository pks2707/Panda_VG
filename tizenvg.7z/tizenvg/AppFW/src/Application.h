#ifndef _AppFW_APPLICATION_H_
#define _AppFW_APPLICATION_H_

#include <string>

#define DEFAULT_WINDOW_WD 1280
#define DEFAULT_WINDOW_HT 720

namespace AppFW
{
    class Application
    {
    public:
        Application(std::string windowTitle = "Sample", uint32_t windowWd = DEFAULT_WINDOW_WD, uint32_t windowHt = DEFAULT_WINDOW_HT);
        void SetBackgroundColor(float red, float green, float blue, float alpha);
        void Run();
        void Exit();

        virtual void OnCreate();
        virtual void OnUpdate(float deltaTime);
        virtual void Render();
        virtual void OnExit();

        static void RenderCb(void* data);


    private:
        bool mShutDown;
    };
}

#endif //_AppFW_APPLICATION_H_