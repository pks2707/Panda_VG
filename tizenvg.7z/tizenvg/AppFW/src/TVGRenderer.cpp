#include "TVGRenderer.h"

#include "WindowManager.h"

namespace AppFW
{
    bool TVGRenderer::mIsInitialized = false;

    TVGRenderer::TVGRenderer()
    :mColor(COLOR_TRANSPARENT_I),
        mShape(nullptr)
    {
        if (!mIsInitialized)
        {
            tvg::Engine::init();

        }
        mCanvas = tvg::GlCanvas::gen(WindowManager::Instance().WindowWidth(),
            WindowManager::Instance().WindowHeight());
    }

    void TVGRenderer::AddRect(float x, float y, float w, float h, float radius)
    {
        mShape = new RectShape(x, y, w, h, radius);
    }

    void TVGRenderer::SetFillColor(ColorI color)
    {
        mColor = color;
    }

    void TVGRenderer::FinishShape()
    {
        auto shapeNode = tvg::ShapeNode::gen();
        switch (mShape->shapeType)
        {
        case ShapeType::Rectangle:
        {
            RectShape* rectShape = static_cast<RectShape*>(mShape);
            shapeNode->appendRect(rectShape->mx, rectShape->my, rectShape->mw, rectShape->mh, rectShape->mr);
            break;
        }
        default:
            break;
        }
        shapeNode->fill(mColor.R, mColor.G, mColor.B, mColor.A);
        mCanvas->push(std::move(shapeNode));
    }

    void TVGRenderer::Render()
    {
        mCanvas->draw();
        mCanvas->sync();
    }
}

