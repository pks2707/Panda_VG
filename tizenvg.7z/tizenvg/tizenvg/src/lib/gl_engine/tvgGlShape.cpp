#include "tvgGlCommon.h"

static Point normalizePoint(GlShape& sdata, Point& pt)
{
  Point p;
  p.x = (pt.x * 2.0f / sdata.viewWd) - 1.0f;
  p.y = -1.0f * ((pt.y * 2.0f / sdata.viewHt) - 1.0f);
  return p;
}

static void addPoint(GlShape& sdata, Point& pt)
{
  sdata.vertices.push_back(normalizePoint(sdata, pt));
}

static void decomposeCubicCurve(GlShape& sdata, Point& cpt1, Point& cpt2, Point& pt)
{

}

bool glShapeGenVertices(const ShapeNode& shape, GlShape& sdata)
{
  const PathCommand* cmds = nullptr;
  auto cmdCnt = shape.pathCommands(&cmds);

  Point* pts = nullptr;
  auto ptsCnt = shape.pathCoords(const_cast<const Point**>(&pts));

  //No actual shape data
  if (cmdCnt == 0 || ptsCnt == 0) return false;

  for (auto i = 0; i < cmdCnt; ++i) {
    switch (*(cmds + i)) {
    case PathCommand::Close: {
      if (sdata.vertices.size() > 0) {
        sdata.vertices.push_back(sdata.vertices[0]);
        pts++;
      }
      break;
    }
    case PathCommand::MoveTo: 
    case PathCommand::LineTo: {
      addPoint(sdata, pts[0]);
      pts++;
      break;
    }
    case PathCommand::CubicTo: {
      decomposeCubicCurve(sdata, pts[0], pts[1], pts[2]);
      pts += 3;
      break;
    }
    }
  }

  return true;
}