#ifndef _TVG_GL_COMMON_H_
#define _TVG_GL_COMMON_H_

#include "tizenvg.h"
#include "tvgCommon.h"

#include <vector>

enum GlAttrib
{
  Location = 0,
};

struct GlShape
{
  float                 viewWd;
  float                 viewHt;
  uint32_t              progObject;
  std::vector<Point>    vertices;
  std::vector<uint32_t> indices;
};

extern const char* COLOR_VERT_SHADER;
extern const char* COLOR_FRAG_SHADER;

uint32_t createShader(const char* vertSrc, const char* fragSrc);
void loadShader(uint32_t program);
void loadUniform(int32_t uniformID, float r, float g, float b, float a);
int32_t getUniformID(uint32_t program, const char* uniformName);
uint32_t generateVertexAttribute();
void UpdateBufferData(uint32_t bufferId, GlShape& sdata);
void drawVertices(GlShape& sdata);

bool glShapeGenVertices(const ShapeNode& shape, GlShape& sdata);

#endif /* _TVG_GL_Shader_H_ */