#include "tvgGlCommon.h"
#include <GLES2/gl2.h>
//#include <EGL/egl.h>
//#include <EGL/eglext.h>

#include <iostream>

const char* COLOR_VERT_SHADER =
"attribute highp vec4 aPosition;	\n"
"uniform highp vec4 ucolor;         \n"
"varying highp vec4 vcolor;         \n"
"void main()                        \n"
"{                                  \n"
"   gl_Position = aPosition;        \n"
"   vcolor = ucolor;                \n"
"}                                  \n";
												
const char* COLOR_FRAG_SHADER =
"varying highp vec4 vcolor;						\n"
"void main()									\n"
"{												\n"
"  gl_FragColor = vcolor;						\n"
"}												\n";

static uint32_t complileShader(uint32_t type, char* shaderSrc)
{
	GLuint shader;
	GLint compiled;

	// Create the shader object
	shader = glCreateShader(type);
	assert(shader);
	
	// Load the shader source
	glShaderSource(shader, 1, &shaderSrc, NULL);

	// Compile the shader
	glCompileShader(shader);

	// Check the compile status
	glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);

	if (!compiled)
	{
		GLint infoLen = 0;

		glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &infoLen);

		if (infoLen > 1)
		{
			char* infoLog = new char[infoLen];
			glGetShaderInfoLog(shader, infoLen, NULL, infoLog);
			std::cout << "Error compiling shader: " << infoLog << std::endl;
			delete[] infoLog;
		}
		glDeleteShader(shader);
		assert(0);
	}

	return shader;
}


uint32_t createShader(const char* vertSrc, const char* fragSrc)
{
	GLuint vShader = complileShader(GL_VERTEX_SHADER, const_cast<char*>(vertSrc));
	GLuint fShader = complileShader(GL_FRAGMENT_SHADER, const_cast<char*>(fragSrc));
	GLint linked;

	// Create the program object
	uint32_t progObj = glCreateProgram();
	assert(progObj);

	glAttachShader(progObj, vShader);
	glAttachShader(progObj, fShader);

	glBindAttribLocation(progObj, GlAttrib::Location, "aPosition");

	// Link the program
	glLinkProgram(progObj);

	// Check the link status
	glGetProgramiv(progObj, GL_LINK_STATUS, &linked);

	if (!linked)
	{
		GLint infoLen = 0;
		glGetProgramiv(progObj, GL_INFO_LOG_LENGTH, &infoLen);
		if (infoLen > 1)
		{
			char* infoLog = new char[infoLen];
			glGetProgramInfoLog(progObj, infoLen, NULL, infoLog);
			std::cout << "Error linking shader: " << infoLog << std::endl;
			delete[] infoLog;

		}
		glDeleteProgram(progObj);
		assert(0);
	}
	return progObj;
}

void loadShader(uint32_t program)
{
	glUseProgram(program);
}

void loadUniform(int32_t uniformID, float r, float g, float b, float a)
{
	glUniform4f(uniformID, r, g, b, a);
}

int32_t getUniformID(uint32_t program, const char* uniformName)
{
	return glGetUniformLocation(program, uniformName);
}

uint32_t generateVertexAttribute()
{
	uint32_t id;
	glGenBuffers(1, &id);
	if (id == GL_INVALID_VALUE)
	{
		assert(0);
	}
	return id;
}

void UpdateBufferData(uint32_t bufferId, GlShape& sdata)
{
	glBindBuffer(GL_ARRAY_BUFFER, bufferId);
	glBufferData(GL_ARRAY_BUFFER, sdata.vertices.size() * sizeof(Point), sdata.vertices.data(), GL_STATIC_DRAW);
	glVertexAttribPointer(GlAttrib::Location, 2, GL_FLOAT, GL_FALSE, sizeof(Point), 0);
	glEnableVertexAttribArray(GlAttrib::Location);
}

void drawVertices(GlShape& sdata)
{
	glDrawArrays(GL_TRIANGLE_FAN, 0, sdata.vertices.size());
}
