/*
 * Copyright (c) 2020 Samsung Electronics Co., Ltd All Rights Reserved
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *               http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
#ifndef _TVG_GL_RENDERER_CPP_
#define _TVG_GL_RENDERER_CPP_

#include "tvgGlCommon.h"
#include "tvgGlRenderer.h"

/************************************************************************/
/* Internal Class Implementation                                        */
/************************************************************************/

static RenderInitializer renderInit;

//struct GlShape
//{
//    //TODO:
//};

/************************************************************************/
/* External Class Implementation                                        */
/************************************************************************/

bool GlRenderer::render(const ShapeNode& shape, void *data)
{
    GlShape* sdata = static_cast<GlShape*>(data);
    if (!sdata) return false;

    size_t r, g, b, a;

    shape.fill(&r, &g, &b, &a);
    loadShader(colorProgObject);
    loadUniform(colorUniformID, (float)r / 255.0f, (float)g / 255.0f, (float)b / 255.0f, (float)a / 255.0f);
    UpdateBufferData(vertexAttrID, *sdata);
    drawVertices(*sdata);

    return true;
}


bool GlRenderer::dispose(const ShapeNode& shape, void *data)
{
    GlShape* sdata = static_cast<GlShape*>(data);
    if (!sdata) return false;

    //TODO:

    free(sdata);
    return true;
}


void* GlRenderer::prepare(const ShapeNode& shape, void* data, UpdateFlag flags)
{
    //prepare shape data
    GlShape* sdata = static_cast<GlShape*>(data);
    if (!sdata) {
        sdata = static_cast<GlShape*>(calloc(1, sizeof(GlShape)));
        assert(sdata);
    }
    sdata->viewWd = shape.getCanvasWidth();
    sdata->viewHt = shape.getCanvasHeight();

    if (flags == UpdateFlag::None) return nullptr;

    //invisible?
    size_t alpha;
    shape.fill(nullptr, nullptr, nullptr, &alpha);
    if (alpha == 0) return sdata;

    if (flags & UpdateFlag::All) {
        if (!glShapeGenVertices(shape, *sdata)) return sdata;
    }
    return sdata;
}

//void GlRenderer::draw(const ShapeNode& shape, void* data, UpdateFlag flags)
//{
//    //prepare shape data
//    assert(data);
//
//    GlShape* sdata = static_cast<GlShape*>(data);
//    size_t r, g, b, a;
//    if (flags == UpdateFlag::None) return;
//
//    if (flags & UpdateFlag::Fill) {
//        shape.fill(&r, &g, &b, &a);
//        loadShader(colorProgObject);
//        loadUniform(colorUniformID, (float)r / 255.0f, (float)g / 255.0f, (float)b / 255.0f, (float)a / 255.0f);
//        UpdateBufferData(vertexAttrID, *sdata);
//        drawVertices(*sdata);
//    }
//}


int GlRenderer::init()
{
    return RenderInitializer::init(renderInit, new GlRenderer);
}


int GlRenderer::term()
{
    return RenderInitializer::term(renderInit);
}


size_t GlRenderer::unref()
{
    return RenderInitializer::unref(renderInit);
}


size_t GlRenderer::ref()
{
    return RenderInitializer::ref(renderInit);
}


GlRenderer::GlRenderer()
{
  colorProgObject = createShader(COLOR_VERT_SHADER, COLOR_FRAG_SHADER);
  loadShader(colorProgObject);
  vertexAttrID = generateVertexAttribute();
  colorUniformID = getUniformID(colorProgObject, "ucolor");
}


GlRenderer* GlRenderer::inst()
{
    return dynamic_cast<GlRenderer*>(RenderInitializer::inst(renderInit));
}



#endif /* _TVG_GL_RENDERER_CPP_ */
