#include "Actor.h"
#include "Renderer.h"

namespace AppFW
{
  uint64_t Actor::s_ActorIDCountetr = 0;

  Actor::Actor()
  :mActorID(++s_ActorIDCountetr),
    mParent(nullptr)
  {
  }

  void Actor::SetSize(float width, float height)
  {
      mSize = std::move(SizeF(width, height));
  }

  SizeF Actor::GetSize()
  {
      return mSize;
  }

  void Actor::SetPosition(float x, float y)
  {
      mPosition = std::move(Point(x, y));
  }

  Point Actor::GetPosition()
  {
      return mPosition;
  }

  void Actor::SetParent(std::shared_ptr<Actor> actor)
  {
    mParent = actor;
  }

  void Actor::Add(std::shared_ptr<Actor> actor)
  {
    mChildActors.push_back(actor);
    actor->SetParent(GetSharedThis());
  }

  void Actor::Remove(std::shared_ptr<Actor> actor)
  {
    uint32_t index = 0;
    for (auto tempActor : mChildActors)
    {
      if (tempActor->mActorID == actor->mActorID)
      {
        break;
      }
      ++index;
    }
    mChildActors.erase(mChildActors.begin() + index);
  }

  void Actor::AddRenderer(std::shared_ptr<Renderer> renderer)
  {
    mRenderTasks.push_back(renderer);
  }

  std::shared_ptr<Renderer> Actor::GetRendererAt(uint32_t index)
  {
    if (index < mRenderTasks.size())
    {
      return mRenderTasks[0];
    } 
    return std::shared_ptr<Renderer>(nullptr);
  }

  void Actor::RemoveRendererAt(uint32_t index)
  {
    if (index >= mRenderTasks.size())
    {
      return;
    }
    mRenderTasks.erase(mRenderTasks.begin() + index);
  }

  void Actor::OnCreate()
  {
  }

  void Actor::OnUpdate()
  {
    for (auto actor : mChildActors)
    {
      actor->OnUpdate();
    }
  }

  void Actor::Render()
  {
    for(auto renderer : mRenderTasks)
    {
      // printf("\n [%s:%d] => Render Actor %llu", __FILE__, __LINE__, GetID());
      renderer->Render();
      for (auto actor : mChildActors)
      {
        actor->Render();
      }
    }
  }
}
