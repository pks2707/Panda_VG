#ifndef _AppFW_VECTOR2_H_
#define _AppFW_VECTOR2_H_

namespace AppFW
{
	struct Vector2
	{
	public:

		Vector2(float x = 0.0f, float y = 0.0f) {
			X = x;
			Y = y;
		}

		Vector2(const Vector2& vec) = default;
		Vector2(Vector2&& vec) = default;

		Vector2& operator= (const Vector2& vec) = default;
		Vector2& operator= (Vector2&& vec) = default;

    Vector2& operator+ (float num)
    {
      X += num;
      Y += num;
      return *this;
    }

    Vector2& operator- (float num)
    {
      X -= num;
      Y -= num;
      return *this;
    }
    
    Vector2& operator* (float num)
    {
      X *= num;
      Y *= num;
      return *this;
    }

    Vector2& operator/ (float num)
    {
      X /= num;
      Y /= num;
      return *this;
    }

    Vector2 NormalizeToView (Vector2 size)
    {
      Vector2 ret;
      ret.X = (X*2.0f / size.Width) - 1.0f;
      ret.Y = -1.0f*((Y*2.0f / size.Height) - 1.0f);
      return ret;
    }

    union {
			float Width;
			float X;
		};

		union {
			float Height;
			float Y;
		};
	};
}

typedef AppFW::Vector2 Point;
typedef AppFW::Vector2 SizeF;

#endif //_AppFW_VECTOR2_H_
