#include "Renderer.h"

namespace AppFW
{
  void Renderer::Render()
  {
  }

}
