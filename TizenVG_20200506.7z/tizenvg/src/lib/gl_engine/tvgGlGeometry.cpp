#include "tvgGlCommon.h"

#include <GLES2/gl2.h>

GlGeometry::GlGeometry()
{
	glGenBuffers(1, &mGlBufferId);
    assert(mGlBufferId != GL_INVALID_VALUE);
}


void GlGeometry::Reset()
{
    mAAPoints.clear();
    mFill.vertices.clear();
    mFill.indices.clear();
    mStroke.vertices.clear();
    mStroke.indices.clear();
}

bool GlGeometry::DecomposeOutline(const Shape &shape)
{
    const PathCommand *cmds = nullptr;
    auto cmdCnt = shape.pathCommands(&cmds);

    Point *pts = nullptr;
    auto ptsCnt = shape.pathCoords(const_cast<const Point **>(&pts));

    //No actual shape data
    if (cmdCnt == 0 || ptsCnt == 0)
        return false;

    for (size_t i = 0; i < cmdCnt; ++i)
    {
        switch (*(cmds + i))
        {
            case PathCommand::Close:
            {
                if ( mAAPoints.size() > 0 &&
                (mAAPoints[0].orgPt != mAAPoints.back().orgPt) )
                {
                    mAAPoints.push_back(mAAPoints[0].orgPt);
                }
                break;
            }
            case PathCommand::MoveTo:
            case PathCommand::LineTo:
            {
                AddPoint(pts[0]);
                pts++;
                break;
            }
            case PathCommand::CubicTo:
            {
                DecomposeCubicCurve(mAAPoints.back().orgPt, pts[0], pts[1], pts[2]);
                pts += 3;
                break;
            }
        }
    }
    return true;
}

bool GlGeometry::GenerateAAPoints(const Shape &shape, float strokeWd, RenderUpdateFlag flag)
{
    std::vector<PointNormals> normalInfo;
    constexpr float blurDir = -1.0f;

    size_t nPoints = mAAPoints.size();
    if (nPoints < 2)
    {
        return false;
    }

    normalInfo.resize(nPoints);

    size_t fPoint = 0;
    size_t sPoint = 1;
    for (size_t i = 0; i < nPoints - 1; ++i)
    {
        fPoint = i;
        sPoint = i + 1;
        if (sPoint == nPoints - 1)
            sPoint = 0;

        GlPoint normal = GetNormal(mAAPoints[fPoint].orgPt, mAAPoints[sPoint].orgPt);

        normalInfo[fPoint].normal1 = normal;
        normalInfo[sPoint].normal2 = normal;
    }
    normalInfo[nPoints - 1].normal1 = normalInfo[0].normal1;
    normalInfo[nPoints - 1].normal2 = normalInfo[0].normal2;

    for (uint32_t i = 0; i < nPoints; ++i)
    {
        normalInfo[i].normalF = normalInfo[i].normal1 + normalInfo[i].normal2;
        normalInfo[i].normalF.normalize();

        float angle = DotProduct(normalInfo[i].normal2, normalInfo[i].normalF);
        if (angle != 0)
            normalInfo[i].normalF = normalInfo[i].normalF / angle;
        else
            normalInfo[i].normalF = GlPoint(0, 0);

        if (flag & RenderUpdateFlag::Fill)
        {
            GlPoint temp = ExtendEdge(mAAPoints[i].orgPt, normalInfo[i].normalF, blurDir * strokeWd);
            if ( (flag & RenderUpdateFlag::Stroke) == 0)
                temp = mAAPoints[i].orgPt;
            mAAPoints[i].fillOuterBlur = temp;
            mAAPoints[i].fillOuter = ExtendEdge(mAAPoints[i].fillOuterBlur, normalInfo[i].normalF, blurDir);
        }
        if (flag & RenderUpdateFlag::Stroke)
        {
            mAAPoints[i].strokeOuterBlur = mAAPoints[i].orgPt;
            mAAPoints[i].strokeOuter = ExtendEdge(mAAPoints[i].strokeOuterBlur, normalInfo[i].normalF, blurDir);
            mAAPoints[i].strokeInner = ExtendEdge(mAAPoints[i].strokeOuter, normalInfo[i].normalF, blurDir * strokeWd);
            mAAPoints[i].strokeInnerBlur = ExtendEdge(mAAPoints[i].strokeInner, normalInfo[i].normalF, blurDir);
        }
    }
    return true;
}

bool GlGeometry::Tesselate(const Shape &shape, float viewWd, float viewHt, RenderUpdateFlag flag)
{
    constexpr float opaque = 1.0f;
    constexpr float transparent = 0.0f;
    printf("\n [%s:%d] => glTesselate flag : %d", __FILE__, __LINE__, flag);
    fflush(stdout);
    try
    {
        if (flag & RenderUpdateFlag::Fill)
        {
            uint32_t i = 0;
            for (size_t pt = 0; pt < mAAPoints.size(); ++pt)
            {
                AddGeometryPoint(mFill, mAAPoints[pt].fillOuter, viewWd, viewHt, opaque);
                if (i > 1)
                {
                    AddTriangleFanIndices(i, mFill.indices);
                }
                ++i;
            }
            for (size_t pt = 1; pt < mAAPoints.size(); ++pt)
            {
                AddGeometryPoint(mFill, mAAPoints[pt - 1].fillOuterBlur, viewWd, viewHt, transparent);
                AddGeometryPoint(mFill, mAAPoints[pt - 1].fillOuter, viewWd, viewHt, opaque);
                AddGeometryPoint(mFill, mAAPoints[pt].fillOuterBlur, viewWd, viewHt, transparent);
                AddGeometryPoint(mFill, mAAPoints[pt].fillOuter, viewWd, viewHt, opaque);
                // ADD_QUAD_VERTICES(i, mFill.indices);
                AddQuadIndices(i, mFill.indices);
            }
    printf("\n [%s:%d] => glTesselate vertices : %lu, indices : %lu", __FILE__, __LINE__, mFill.vertices.size(), mFill.indices.size());
    fflush(stdout);
        }
        if (flag & RenderUpdateFlag::Stroke)
        {
            uint32_t i = 0;
            for (size_t pt = 1; pt < mAAPoints.size(); ++pt)
            {
                AddGeometryPoint(mStroke, mAAPoints[pt - 1].strokeOuter, viewWd, viewHt, opaque);
                AddGeometryPoint(mStroke, mAAPoints[pt - 1].strokeInner, viewWd, viewHt, opaque);
                AddGeometryPoint(mStroke, mAAPoints[pt].strokeOuter, viewWd, viewHt, opaque);
                AddGeometryPoint(mStroke, mAAPoints[pt].strokeInner, viewWd, viewHt, opaque);
                AddQuadIndices(i, mStroke.indices);
            }
            for (size_t pt = 1; pt < mAAPoints.size(); ++pt)
            {
                AddGeometryPoint(mStroke, mAAPoints[pt - 1].strokeOuterBlur, viewWd, viewHt, transparent);
                AddGeometryPoint(mStroke, mAAPoints[pt - 1].strokeOuter, viewWd, viewHt, opaque);
                AddGeometryPoint(mStroke, mAAPoints[pt].strokeOuterBlur, viewWd, viewHt, transparent);
                AddGeometryPoint(mStroke, mAAPoints[pt].strokeOuter, viewWd, viewHt, opaque);
                AddQuadIndices(i, mStroke.indices);
            }
            for (size_t pt = 1; pt < mAAPoints.size(); ++pt)
            {
                AddGeometryPoint(mStroke, mAAPoints[pt - 1].strokeInner, viewWd, viewHt, opaque);
                AddGeometryPoint(mStroke, mAAPoints[pt - 1].strokeInnerBlur, viewWd, viewHt, transparent);
                AddGeometryPoint(mStroke, mAAPoints[pt].strokeInner, viewWd, viewHt, opaque);
                AddGeometryPoint(mStroke, mAAPoints[pt].strokeInnerBlur, viewWd, viewHt, transparent);
                AddQuadIndices(i, mStroke.indices);
            }
    printf("\n [%s:%d] => glTesselate vertices : %lu, indices : %lu", __FILE__, __LINE__, mStroke.vertices.size(), mStroke.indices.size());
    fflush(stdout);
        }
    }
    catch (std::exception &e)
    {
        std::cerr << "exception caught: " << e.what() << '\n';
    }
    mAAPoints.clear();
    return true;
}

void GlGeometry::UpdateBufferData(VertexDataArray& geometry)
{
	glBindBuffer(GL_ARRAY_BUFFER, mGlBufferId);
	glBufferData(GL_ARRAY_BUFFER, geometry.vertices.size() * sizeof(VertexData), geometry.vertices.data(), GL_STATIC_DRAW);
	glVertexAttribPointer(GlAttrib::Location, 3, GL_FLOAT, GL_FALSE, sizeof(VertexData), 0);
	glEnableVertexAttribArray(GlAttrib::Location);
}

void GlGeometry::DrawVertices(VertexDataArray& geometry)
{
    // printf("\n [%s:%d] => geometry.vertices : %lu", __FILE__, __LINE__, geometry.vertices.size());
    // printf("\n [%s:%d] => geometry.indices : %lu", __FILE__, __LINE__, geometry.indices.size());
    // fflush(stdout);
    glDrawElements(GL_TRIANGLES, geometry.indices.size(), GL_UNSIGNED_INT, geometry.indices.data());
    //glDrawArrays(GL_TRIANGLE_FAN, 0, geometry.vertices.size());
}

VertexDataArray& GlGeometry::GetFill()
{
    return mFill;
}

VertexDataArray& GlGeometry::GetStroke()
{
    return mStroke;
}


GlPoint GlGeometry::NormalizePoint(GlPoint &pt, float viewWd, float viewHt)
{
    GlPoint p;
    p.x = (pt.x * 2.0f / viewWd) - 1.0f;
    p.y = -1.0f * ((pt.y * 2.0f / viewHt) - 1.0f);
    return p;
}

void GlGeometry::AddGeometryPoint(VertexDataArray &geometry, GlPoint &pt, float viewWd, float viewHt, float opacity)
{
    VertexData tv = { NormalizePoint(pt, viewWd, viewHt), opacity};
    geometry.vertices.push_back(tv);
}

GlPoint GlGeometry::GetNormal(GlPoint &p1, GlPoint &p2)
{
    GlPoint normal = p1 - p2;
    normal.normalize();
    return GlPoint(-normal.y, normal.x);
}

float GlGeometry::DotProduct(GlPoint &p1, GlPoint &p2)
{
    return (p1.x * p2.x + p1.y * p2.y);
}

GlPoint GlGeometry::ExtendEdge(GlPoint &pt, GlPoint &normal, float scalar)
{
    GlPoint tmp = (normal * scalar);
    return (pt + tmp);
}

void GlGeometry::AddPoint(const GlPoint &pt)
{
    mAAPoints.push_back(GlPoint(pt.x, pt.y));
}

void GlGeometry::AddTriangleFanIndices(uint32_t &curPt, std::vector<uint32_t> &indices)
{
    indices.push_back(0);
    indices.push_back(curPt - 1);
    indices.push_back(curPt);
}

void GlGeometry::AddQuadIndices(uint32_t &curPt, std::vector<uint32_t> &indices)
{
    indices.push_back(curPt);
    indices.push_back(curPt + 1);
    indices.push_back(curPt + 2);
    indices.push_back(curPt + 1);
    indices.push_back(curPt + 3);
    indices.push_back(curPt + 2);
    curPt += 4;
}

bool GlGeometry::IsBezierFlat(const GlPoint &p1, const GlPoint &c1, const GlPoint &c2, const GlPoint &p2)
{
    GlPoint diff1 = (c1 * 3.0f) - (p1 * 2.0f) - p2;
    GlPoint diff2 = (c2 * 3.0f) - (p2 * 2.0f) - p1;

    diff1.mod();
    diff2.mod();
    if (diff1.x < diff2.x)
        diff1.x = diff2.x;
    if (diff1.y < diff2.y)
        diff1.y = diff2.y;

    if (diff1.x + diff1.y <= 0.5f)
        return true;
    return false;
}

void GlGeometry::DecomposeCubicCurve(const GlPoint &pt1, const GlPoint &cpt1, const GlPoint &cpt2, const GlPoint &pt2)
{
    if (IsBezierFlat(pt1, cpt1, cpt2, pt2))
    {
        AddPoint(pt2);
        return;
    }
    GlPoint p12 = (pt1 + cpt1) * 0.5f;
    GlPoint p23 = (cpt1 + cpt2) * 0.5f;
    GlPoint p34 = (cpt2 + pt2) * 0.5f;

    GlPoint p123 = (p12 + p23) * 0.5f;
    GlPoint p234 = (p23 + p34) * 0.5f;

    GlPoint p1234 = (p123 + p234) * 0.5f;

    DecomposeCubicCurve(pt1, p12, p123, p1234);
    DecomposeCubicCurve(p1234, p234, p34, pt2);
}

