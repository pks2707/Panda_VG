#ifndef _TVG_GL_COMMON_H_
#define _TVG_GL_COMMON_H_

#include "tizenvg.h"
#include "tvgCommon.h"

#include <vector>

enum GlAttrib
{
  Location = 0,
};

class GlPoint
{
public:
    float x;
    float y;

    GlPoint(float pX = 0.0f, float pY = 0.0f)
        :x(pX),
        y(pY)
    {}

    GlPoint(const Point& rhs)
        :GlPoint(rhs.x, rhs.y)
    {}

    GlPoint(const GlPoint& rhs) = default;
    GlPoint(GlPoint&& rhs) = default;

    GlPoint& operator= (const GlPoint& rhs) = default;
    GlPoint& operator= (GlPoint&& rhs) = default;

    GlPoint& operator= (const Point& rhs)
    {
        x = rhs.x;
        y = rhs.y;
        return *this;
    }

    bool operator== (const GlPoint& rhs) {
        if (&rhs == this)
            return true;
        if (rhs.x == this->x && rhs.y == this->y)
            return true;
        return false;
    }
    bool operator!= (const GlPoint& rhs) {
        if (&rhs == this)
            return true;
        if (rhs.x != this->x || rhs.y != this->y)
            return true;
        return false;
    }
    GlPoint operator+ (const GlPoint& rhs) const {
        return GlPoint(x + rhs.x, y + rhs.y);
    }
    GlPoint operator+ (const float c) const {
        return GlPoint(x + c, y + c);
    }
    GlPoint operator- (const GlPoint& rhs) const {
        return GlPoint(x - rhs.x, y - rhs.y);
    }
    GlPoint operator- (const float c) const {
        return GlPoint(x - c, y - c);
    }
    GlPoint operator* (const GlPoint& rhs) const {
        return GlPoint(x * rhs.x, y * rhs.y);
    }
    GlPoint operator* (const float c) const {
        return GlPoint(x * c, y * c);
    }
    GlPoint operator/ (const GlPoint& rhs) const {
        return GlPoint(x / rhs.x, y / rhs.y);
    }
    GlPoint operator/ (const float c) const {
        return GlPoint(x / c, y / c);
    }
    void mod()
    {
        x = fabsf(x);
        y = fabsf(y);
    }
    void normalize()
    {
        float length = sqrtf( (x * x) + (y * y) );
        if (length != 0.0f) {
            const float inverseLen = 1.0f / length;
            x *= inverseLen;
            y *= inverseLen;
        }
    }
};

struct SmoothPoint
{
    GlPoint orgPt;
    GlPoint fillOuterBlur;
    GlPoint fillOuter;
    GlPoint strokeOuterBlur;
    GlPoint strokeOuter;
    GlPoint strokeInnerBlur;
    GlPoint strokeInner;

    SmoothPoint(GlPoint pt) 
        :orgPt(pt),
        fillOuterBlur(pt),
        fillOuter(pt),
        strokeOuterBlur(pt),
        strokeOuter(pt),
        strokeInnerBlur(pt),
        strokeInner(pt)
    {
    }
};

struct PointNormals
{
    GlPoint normal1;
    GlPoint normal2;
    GlPoint normalF;
};

struct VertexData
{
   GlPoint point;
   float opacity = 0.0f;
};

struct VertexDataArray
{
    std::vector<VertexData>   vertices;
    std::vector<uint32_t>     indices;
};

extern const char* COLOR_VERT_SHADER;
extern const char* COLOR_FRAG_SHADER;

class GlShader
{
public:
    void CreateShader(const char* vertSrc, const char* fragSrc);
    void LoadShader();
    int32_t RegisterProperty(const char* propertyName);
    void LoadProperty(int32_t propertyId, float r, float g, float b, float a);
private:
    uint32_t ComplileShader(uint32_t type, char* shaderSrc);
    
    uint32_t mColorProgram;
};

class GlGeometry
{
public:
    GlGeometry();
    void Reset();
    bool DecomposeOutline(const Shape& shape);
    bool GenerateAAPoints(const Shape& shape, float strokeWd, RenderUpdateFlag flag);
    bool Tesselate(const Shape &shape, float viewWd, float viewHt, RenderUpdateFlag flag);
    void UpdateBufferData(VertexDataArray& geomtry);
    void DrawVertices(VertexDataArray& geomtry);
    
    VertexDataArray& GetFill();
    VertexDataArray& GetStroke();
    
private:
    GlPoint NormalizePoint(GlPoint &pt, float viewWd, float viewHt);
    void AddGeometryPoint(VertexDataArray &geometry, GlPoint &pt, float viewWd, float viewHt, float opacity);
    GlPoint GetNormal(GlPoint &p1, GlPoint &p2);
    float DotProduct(GlPoint &p1, GlPoint &p2);
    GlPoint ExtendEdge(GlPoint &pt, GlPoint &normal, float scalar);
    void AddPoint(const GlPoint &pt);
    void AddTriangleFanIndices(uint32_t &curPt, std::vector<uint32_t> &indices);
    void AddQuadIndices(uint32_t &curPt, std::vector<uint32_t> &indices);
    bool IsBezierFlat(const GlPoint &p1, const GlPoint &c1, const GlPoint &c2, const GlPoint &p2);
    void DecomposeCubicCurve(const GlPoint &pt1, const GlPoint &cpt1, const GlPoint &cpt2, const GlPoint &pt2);

    uint32_t    mGlBufferId = 0;
    std::vector<SmoothPoint> mAAPoints;
    VertexDataArray mFill;
    VertexDataArray mStroke;
};

struct GlShape
{
  float             viewWd;
  float             viewHt;
  
  std::unique_ptr<GlGeometry> geometry;
};


#endif /* _TVG_GL_Shader_H_ */