#ifndef _AppFW_UTILITY_H_
#define _AppFW_UTILITY_H_

#include "Logger.h"


#ifdef _WIN32
#define P_UTIL_API  __cdecl
#define P_CALLBACK  __cdecl
#else
#define P_UTIL_API
#define P_CALLBACK
#endif

namespace AppFW
{
	class Utility
	{
	public:
		static uint64_t GetTime();

	private:
		Utility() = default;
	};
}

#endif //_AppFW_UTILITY_H_
