#ifndef _AppFW_NATIVEWINDOW_UNIX_H_
#define _AppFW_NATIVEWINDOW_UNIX_H_

#include "NativeWindow.h"

#include  <X11/Xlib.h>
#include  <X11/Xatom.h>
#include  <X11/Xutil.h>

namespace AppFW
{
	class NativeWindow_Unix : public NativeWindow
	{
	public:
		NativeWindow_Unix();
		~NativeWindow_Unix() = default;

		NativeWindow_Unix(const NativeWindow_Unix& win) = default;
		NativeWindow_Unix(NativeWindow_Unix&& win) = default;

		NativeWindow_Unix& operator=(const NativeWindow_Unix& win) = default;
		NativeWindow_Unix& operator=(NativeWindow_Unix&& win) = default;

		bool HandleEvent();
		EGLNativeWindowType GetWindowHandle();
		EGLNativeDisplayType GetWindowContext();

		// static LRESULT WINAPI WindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

	private:
		virtual void CreateNativeWindow();

        Display*    mXDisplay;
        Window      mRootWindow;
        Window      mXWindow;
        Atom mWmDeleteMessage;
        XSetWindowAttributes    mSWA;
	};
}



#endif //_AppFW_NATIVEWINDOW_UNIX_H_
