#ifndef _AppFW_LOGGER_H_
#define _AppFW_LOGGER_H_

#include <iostream>
#include <assert.h>

namespace AppFW
{
	class Logger
	{
	public:
		enum LogLevel
		{
			NONE = 0x0,
			ERROR = 0x1,
			DEBUG = 0x3,
			INFO = 0x7,
		};

		static void Initialize(LogLevel level = LogLevel::ERROR)
		{
			mLevel = level;
		}

		static bool CheckLevel(LogLevel l)
		{
			if ((mLevel & l) == 0)
				return false;
			return true;
		}

	private:
		static LogLevel mLevel;
	};
}

#define LOG(format, ...) printf(format, __VA_ARGS__);
#define LOGD(format, ...) if(AppFW::Logger::CheckLevel(AppFW::Logger::LogLevel::DEBUG)) \
							printf("[%s:%d] => " format, __FUNCTION__, __LINE__, __VA_ARGS__); \
							printf("\n")

#define LOGE(format, ...) if(AppFW::Logger::CheckLevel(AppFW::Logger::LogLevel::ERROR)) \
							printf("[%s:%d] => " format, __FUNCTION__, __LINE__, __VA_ARGS__); \
							printf("\n")

#define ASSERT(x) if((x)== 0) assert(0)

#endif //_TVG_LOGGER_H_