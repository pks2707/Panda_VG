#ifndef _AppFW_NATIVEWINDOW_WIN_H_
#define _AppFW_NATIVEWINDOW_WIN_H_

#if defined(_WIN32) || defined(_WIN64)

#include "NativeWindow.h"

#include <Windows.h>

namespace AppFW
{
	class NativeWindow_Win : public NativeWindow
	{
	public:
		NativeWindow_Win();
		~NativeWindow_Win() = default;

		NativeWindow_Win(const NativeWindow_Win& win) = default;
		NativeWindow_Win(NativeWindow_Win&& win) = default;

		NativeWindow_Win& operator=(const NativeWindow_Win& win) = default;
		NativeWindow_Win& operator=(NativeWindow_Win&& win) = default;

		bool HandleEvent();
		EGLNativeWindowType GetWindowHandle();
		EGLNativeDisplayType GetWindowContext();

		static LRESULT WINAPI WindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

	private:
		virtual void CreateNativeWindow();

		HWND mWindowHandle;
	};
}

#endif //defined(_WIN32) || defined(_WIN64)
#endif //_AppFW_NATIVEWINDOW_WIN_H_
