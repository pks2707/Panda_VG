#ifndef _AppFW_VECTOR4_H_
#define _AppFW_VECTOR4_H_

namespace AppFW
{
	template <class T>
	class Vector4
	{
	public:
		Vector4(T x, T y, T z, T w)
		{
			X = x;
			Y = y;
			Width = z;
			Height = w;
		}

		union
		{
			T X;
			T Left;
			T R;
		};
		union
		{
			T Y;
			T Top;
			T G;
		};
		union
		{
			T Width;
			T Right;
			T B;
		};
		union
		{
			T Height;
			T Bottom;
			T A;
		};
	};

	typedef Vector4<float> ColorF;
	typedef Vector4<unsigned int> ColorI;
}

#define COLOR_TRANSPARENT_I ColorI(0, 0, 0, 0)
#endif //_AppFW_VECTOR4_H_