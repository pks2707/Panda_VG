#ifndef _AppFW_TVGRENDERER_H_
#define _AppFW_TVGRENDERER_H_

#include "Renderer.h"
#include "Vector4.h"
#include "tizenvg.h"

#include <memory>

namespace AppFW
{
    enum class ShapeType
    {
        NONE = 0,
        RECTANGLE = 1,
        ELLIPSE = 2,
    };
    struct Shape
    {
        Shape(ShapeType type = ShapeType::NONE) :shapeType(type) {}

        ShapeType shapeType;
    };

    struct RectShape : public Shape
    {
        RectShape(float x = 0.0f, float y = 0.0f, float w = 0.0f, float h = 0.0f, float r = 0.0f)
            : Shape(ShapeType::RECTANGLE),
            mx(x),
            my(y),
            mw(w),
            mh(h),
            mr(r)
        {
        }

        float mx;
        float my;
        float mw;
        float mh;
        float mr;
    };
    struct EllipseShape : public Shape
    {
        EllipseShape(float cx = 0.0f, float cy = 0.0f, float rx = 0.0f, float ry = 0.0f)
            : Shape(ShapeType::ELLIPSE),
            mcx(cx),
            mcy(cy),
            mrx(rx),
            mry(ry)
        {
        }

        float mcx;
        float mcy;
        float mrx;
        float mry;
    };

    class TVGRenderer : public Renderer
    {
    public:
        enum PaintMethod
        {
            NONE = 0,
            FILL = 1,
            STROKE = 2,
            ALL = 3,
        };

        TVGRenderer();
        ~TVGRenderer() = default;

        TVGRenderer(const TVGRenderer& renderer) = default;
        TVGRenderer(TVGRenderer&& renderer) = default;
    
        TVGRenderer& operator= (const TVGRenderer& renderer) = default;
        TVGRenderer& operator= (TVGRenderer && renderer) = default;

        void AddRect(float x, float y, float w, float h, float radius);
        void AddEllipse(float cx, float cy, float rx, float ry);
        void SetFill(ColorI color);
        void SetStroke(ColorI color, uint32_t strokeWd);
        void FinishShape();
        void Render() override;

    private:
        static bool     mIsInitialized;
        ColorI          mFillColor;
        ColorI          mStrokeColor;
        uint32_t        mStrokeWd;
        uint32_t        mPaintMethod;
        Shape*          mShape;
        std::unique_ptr<tvg::GlCanvas> mCanvas = nullptr;
    };

    typedef std::shared_ptr<TVGRenderer> SP_TVGRenderer;

}

#endif //_AppFW_TVGRENDERER_H_
