#include "NativeWindow.h"

namespace AppFW
{
	NativeWindow::NativeWindow()
	:mAppData(nullptr),
		mRenderCb(nullptr),
		mUpdateCb(nullptr),
		mKeyCb(nullptr),
		mShutdownCb(nullptr),
		mWindowTitle(""),
		mWindowSize(800.0f, 600.0f)
	{
	}

	void NativeWindow::Initialize(std::string title, uint32_t windowWidth, uint32_t windowHeight)
	{
		SetWindowTitle(title);
		SetWindowSize(Vector2((float)windowWidth, (float)windowHeight));
		CreateNativeWindow();
	}

  void NativeWindow::Start()
  {
    for (auto actor : mActorList)
    {
      actor->OnCreate();
    }
  }

  void NativeWindow::Add(SP_Actor actor)
  {
    mActorList.push_back(actor);
  }

  void NativeWindow::Remove(SP_Actor actor)
  {
    uint32_t index = 0;
    for (auto tempActor : mActorList)
    {
      if (tempActor->GetID() == actor->GetID())
      {
        break;
      }
      ++index;
    }
    mActorList.erase(mActorList.begin() + index);
  }

  void NativeWindow::Render()
  {
    for (auto actor : mActorList)
    {
        actor->Render();
    }
  }

	void NativeWindow::SetWindowTitle(std::string strWindowTitle)
	{
		mWindowTitle = strWindowTitle;
	}

	std::string NativeWindow::WindowTitle() const
	{
		return mWindowTitle;
	}

	void NativeWindow::SetWindowSize(const Vector2 windowSize)
	{
		mWindowSize = windowSize;
	}

	Vector2 NativeWindow::WindowSize() const
	{
		return mWindowSize;
	}

	uint32_t NativeWindow::WindowWidth() const
	{
		return static_cast<uint32_t>(mWindowSize.Width);
	}

	uint32_t NativeWindow::WindowHeight() const
	{
		return static_cast<uint32_t>(mWindowSize.Height);
	}

	void NativeWindow::SetRenderCallback(RenderCallback cb)
	{
		mRenderCb = cb;
	}

	void NativeWindow::SetUpdateRenderCallback(UpdateCallback cb)
	{
		mUpdateCb = cb;
	}

	void NativeWindow::SetKeyCallback(KeyCallback cb)
	{
		mKeyCb = cb;
	}

	void NativeWindow::SetShutDownCallback(ShutdownCallback cb)
	{
		mShutdownCb = cb;
	}

	void NativeWindow::SetApplicationData(void * data)
	{
		mAppData = data;
	}
}
