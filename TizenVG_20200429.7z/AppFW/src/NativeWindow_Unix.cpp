#include "NativeWindow_Unix.h"
#include "Utility.h"

#include <string.h>

namespace AppFW
{
	NativeWindow_Unix::NativeWindow_Unix()
	:mXDisplay(nullptr),
    mRootWindow(0),
    mXWindow(0)
    {
	}

    bool NativeWindow_Unix::HandleEvent()
    {
        XEvent xev;
        KeySym key;
        bool isRunning = true;
        char text;

        // Pump all messages from X server. Keypresses are directed to keyfunc (if defined)
        while ( XPending ( mXDisplay ) )
        {
            XNextEvent( mXDisplay, &xev );
            if ( xev.type == KeyPress )
            {
                if (XLookupString(&xev.xkey,&text,1,&key,nullptr)==1)
                {
                    // Key Callback
                    // if (mKeyFunction != nullptr)
                    //     mKeyFunction(mUserData, text, 0, 0);
                }
            }
            if (xev.type == ClientMessage) {
                if (xev.xclient.data.l[0] == static_cast<int64_t>(mWmDeleteMessage)) {
                    isRunning = false;
                }
            }
            if ( xev.type == DestroyNotify )
                isRunning = false;
        }

        if (mRenderCb)
        {
            mRenderCb(mAppData);
        }
        return isRunning;
    }

    EGLNativeWindowType NativeWindow_Unix::GetWindowHandle()
    {
        return static_cast<EGLNativeWindowType>(mXWindow);
    }

    EGLNativeDisplayType NativeWindow_Unix::GetWindowContext()
    {
        return static_cast<EGLNativeDisplayType>(mXDisplay);
    }

    void NativeWindow_Unix::CreateNativeWindow()
    {
        mXDisplay = XOpenDisplay(nullptr);
        XSetWindowAttributes xattr;
        Atom wm_state;
        XWMHints hints;
        XEvent xev;

        ASSERT(mXDisplay);

        mRootWindow = DefaultRootWindow(mXDisplay);

        mSWA.event_mask = ExposureMask | PointerMotionMask | KeyPressMask;
        mXWindow = XCreateWindow(
            mXDisplay, mRootWindow,
            0, 0, WindowWidth(), WindowHeight(), 0,
            CopyFromParent, InputOutput,
            CopyFromParent, CWEventMask,
            &mSWA);
        mWmDeleteMessage = XInternAtom(mXDisplay, "WM_DELETE_WINDOW", true);
        XSetWMProtocols(mXDisplay, mXWindow, &mWmDeleteMessage, 1);

        xattr.override_redirect = false;
        XChangeWindowAttributes(mXDisplay, mXWindow, CWOverrideRedirect, &xattr);

        hints.input = true;
        hints.flags = InputHint;
        XSetWMHints(mXDisplay, mXWindow, &hints);

        // make the window visible on the screen
        XMapWindow(mXDisplay, mXWindow);
        XStoreName(mXDisplay, mXWindow, WindowTitle().c_str());

        // get identifiers for the provided atom name strings
        wm_state = XInternAtom(mXDisplay, "_NET_WM_STATE", false);

        memset(&xev, 0, sizeof(xev));
        xev.type = ClientMessage;
        xev.xclient.window = mXWindow;
        xev.xclient.message_type = wm_state;
        xev.xclient.format = 32;
        xev.xclient.data.l[0] = 1;
        xev.xclient.data.l[1] = false;
        XSendEvent(
            mXDisplay,
            DefaultRootWindow(mXDisplay),
            false,
            SubstructureNotifyMask,
            &xev);
        return;
    }
    
} // namespace AppFW
