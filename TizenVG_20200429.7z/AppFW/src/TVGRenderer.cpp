#include "TVGRenderer.h"

#include "WindowManager.h"

namespace AppFW
{
    bool TVGRenderer::mIsInitialized = false;

    TVGRenderer::TVGRenderer()
        :mFillColor(COLOR_TRANSPARENT_I),
        mStrokeColor(COLOR_TRANSPARENT_I),
        mStrokeWd(0),
        mPaintMethod(PaintMethod::NONE),
        mShape(nullptr)
    {
        if (!mIsInitialized)
        {
            tvg::Engine::init();

        }
        printf("\n [%s:%d] => GlCanvas gen", __FILE__, __LINE__);

        mCanvas = tvg::GlCanvas::gen(WindowManager::Instance().WindowWidth(),
            WindowManager::Instance().WindowHeight());
    }

    void TVGRenderer::AddRect(float x, float y, float w, float h, float radius)
    {
        mShape = new RectShape(x, y, w, h, radius);
    }

    void TVGRenderer::AddEllipse(float cx, float cy, float rx, float ry)
    {
        mShape = new EllipseShape(cx, cy, rx, ry);
    }

    void TVGRenderer::SetFill(ColorI color)
    {
        mFillColor = color;
        mPaintMethod |= PaintMethod::FILL;
    }

    void TVGRenderer::SetStroke(ColorI color, uint32_t strokeWd)
    {
        mStrokeColor = color;
        mStrokeWd = strokeWd;
        mPaintMethod |= PaintMethod::STROKE;
    }

    void TVGRenderer::FinishShape()
    {
		printf("\n [%s:%d] => shapeType : %d, mPaintMethod : %d", __FILE__, __LINE__, (int)mShape->shapeType, mPaintMethod);
        fflush(stdout);
        auto shapeNode = tvg::ShapeNode::gen();
        switch (mShape->shapeType)
        {
        case ShapeType::RECTANGLE:
        {
            RectShape* shape = static_cast<RectShape*>(mShape);
            shapeNode->appendRect(shape->mx, shape->my, shape->mw, shape->mh, shape->mr);
            break;
        }
        case ShapeType::ELLIPSE:
        {
            EllipseShape* shape = static_cast<EllipseShape*>(mShape);
            shapeNode->appendCircle(shape->mcx, shape->mcy, shape->mrx, shape->mry);
            break;
        }
        default:
            break;
        }
        if (mPaintMethod & PaintMethod::FILL) {
            shapeNode->fill(mFillColor.R, mFillColor.G, mFillColor.B, mFillColor.A);
        }
        if (mPaintMethod & PaintMethod::STROKE) {
            shapeNode->stroke(mStrokeColor.R, mStrokeColor.G, mStrokeColor.B, mStrokeColor.A, mStrokeWd);
        }

        mCanvas->push(std::move(shapeNode));
    }

    void TVGRenderer::Render()
    {
        mCanvas->draw();
        mCanvas->sync();
    }
}

