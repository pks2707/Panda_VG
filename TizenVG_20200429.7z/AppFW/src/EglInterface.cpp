#include "EglInterface.h"
#include "Utility.h"

#include <string.h>

namespace AppFW
{
	EglInterface* EglInterface::mInstance = nullptr;

	void EglInterface::Initialize(Vector2 windowSize, EGLNativeDisplayType nativeDisplay, EGLNativeWindowType nativeWindow)
	{
		mWindowSize = windowSize;
		EGLConfig config;
		EGLint majorVersion;
		EGLint minorVersion;
		EGLint contextAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };

		mNativeDisplay = nativeDisplay;
		mNativeWindow = nativeWindow;

		mEglDisplay = eglGetDisplay(mNativeDisplay);
		if (mEglDisplay == EGL_NO_DISPLAY)
		{
			PRINT_EGL_ERROR("eglGetDisplay Failed");
			ASSERT(mEglDisplay);
		}

		// Initialize EGL
		if (!eglInitialize(mEglDisplay, &majorVersion, &minorVersion))
		{
			PRINT_EGL_ERROR("eglInitialize Failed");
			ASSERT(0);
		}

		{
			EGLint numConfigs = 0;
			EGLint attribList[] =
			{
			   EGL_RED_SIZE,       8,
			   EGL_GREEN_SIZE,     8,
			   EGL_BLUE_SIZE,      8,
			   EGL_ALPHA_SIZE,     8,
			   EGL_SAMPLES,        4,
			   EGL_SAMPLE_BUFFERS, 1,
			   // if EGL_KHR_create_context extension is supported, then we will use
			   // EGL_OPENGL_ES3_BIT_KHR instead of EGL_OPENGL_ES2_BIT in the attribute list
			   EGL_RENDERABLE_TYPE, GetContextRenderableType(mEglDisplay),
			   EGL_NONE
			};

			// Choose config
			if (!eglChooseConfig(mEglDisplay, attribList, &config, 1, &numConfigs) || numConfigs < 1)
			{
				PRINT_EGL_ERROR("eglInitialize Failed");
				ASSERT(0);
			}
		}
		// Create a surface
		mEglSurface = eglCreateWindowSurface(mEglDisplay, config, mNativeWindow, NULL);
		if (mEglSurface == EGL_NO_SURFACE)
		{
			PRINT_EGL_ERROR("eglCreateWindowSurface Failed");
			ASSERT(0);
		}

		// Create a GL context
		mEglContext = eglCreateContext(mEglDisplay, config, EGL_NO_CONTEXT, contextAttribs);
		if (mEglContext == EGL_NO_CONTEXT)
		{
			PRINT_EGL_ERROR("eglCreateContext Failed");
			ASSERT(0);
		}

		// Make the context current
		if (!eglMakeCurrent(mEglDisplay, mEglSurface, mEglSurface, mEglContext))
		{
			PRINT_EGL_ERROR("eglMakeCurrent Failed");
			ASSERT(0);
		}
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glEnable(GL_BLEND);
	}

	void EglInterface::SetBackgroundColor(float r, float g, float b, float a)
	{
		mWindowBgColor = ColorF(r, g, b, a);
		glClearColor(mWindowBgColor.R, mWindowBgColor.G, mWindowBgColor.B, mWindowBgColor.A);
	}

	void EglInterface::StartRender()
	{
    // Set the viewport
		glViewport(0, 0, static_cast<int>(mWindowSize.Width), static_cast<int>(mWindowSize.Height));

		// Clear the color buffer
		glClear(GL_COLOR_BUFFER_BIT);
	}

	void EglInterface::FinishRender()
	{
		eglSwapBuffers(mEglDisplay, mEglSurface);
	}

	EglInterface& EglInterface::Instance()
	{
		if (!mInstance)
		{
			mInstance = new EglInterface();
		}
		return *mInstance;
	}

	EglInterface::EglInterface()
	:mNativeDisplay((EGLNativeDisplayType)0),
		mNativeWindow((EGLNativeWindowType)0),
		mEglDisplay(nullptr),
		mEglContext(nullptr),
		mEglSurface(nullptr),
		mWindowSize(0, 0),
		mWindowBgColor(0.0f, 0.0f, 0.0f, 0.0f)
		
	{

	}

	EGLint EglInterface::GetContextRenderableType(EGLDisplay eglDisplay)
	{
#ifdef EGL_KHR_create_context
		const char *extensions = eglQueryString(eglDisplay, EGL_EXTENSIONS);

		// check whether EGL_KHR_create_context is in the extension string
		if (extensions != NULL && strstr(extensions, "EGL_KHR_create_context"))
		{
			// extension is supported
			return EGL_OPENGL_ES3_BIT_KHR;
		}
#endif
		// extension is not supported
		return EGL_OPENGL_ES2_BIT;
	}

}
