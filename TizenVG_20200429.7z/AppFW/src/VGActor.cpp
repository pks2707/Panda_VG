#include "VGActor.h"
#include "TVGRenderer.h"

#include <memory>

namespace AppFW
{
    VGActor::VGActor()
    {
        SP_TVGRenderer renderer = std::make_shared<TVGRenderer>();
        AddRenderer(renderer);
    }


    void VGActor::AddRect(float radius)
    {
        SP_TVGRenderer renderer = std::dynamic_pointer_cast<TVGRenderer>(GetRendererAt(0));
        renderer->AddRect(GetPosition().X, GetPosition().Y, GetSize().Width, GetSize().Height, radius);
    }

    void VGActor::AddEllipse()
    {
        SP_TVGRenderer renderer = std::dynamic_pointer_cast<TVGRenderer>(GetRendererAt(0));
        float rx = GetSize().Width / 2;
        float ry = GetSize().Height / 2;
        float cx = GetPosition().X + rx;
        float cy = GetPosition().Y + ry;
        renderer->AddEllipse(cx, cy, rx, ry);
    }

    void VGActor::SetFill(ColorI color)
    {
        SP_TVGRenderer renderer = std::dynamic_pointer_cast<TVGRenderer>(GetRendererAt(0));
        renderer->SetFill(color);
    }

    void VGActor::SetStroke(ColorI color, uint32_t width)
    {
        SP_TVGRenderer renderer = std::dynamic_pointer_cast<TVGRenderer>(GetRendererAt(0));
        renderer->SetStroke(color, width);
    }

    void VGActor::Upload()
    {
        SP_TVGRenderer renderer = std::dynamic_pointer_cast<TVGRenderer>(GetRendererAt(0));
        renderer->FinishShape();
    }
}
