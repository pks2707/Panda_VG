#include "Application.h"
#include "WindowManager.h"
#include "VGActor.h"

using namespace AppFW;

class VGActorSample : public Application
{
    SP_VGActor rect;
    SP_VGActor roundrect;
    SP_VGActor ellipse;

public:
    VGActorSample()
        :Application("VG Sample", 1920, 1080)
    {

    }
    void OnCreate() override
    {
        rect = std::make_shared<VGActor>();
        rect->SetPosition(100, 100);
        rect->SetSize(400, 400);
        rect->AddRect(0.0f);
        rect->SetFill(ColorI(255, 0, 0, 255));
        rect->SetStroke(ColorI(255, 255, 0, 255), 10);
        rect->Upload();
        WindowManager::Instance().Add(rect);

        roundrect = std::make_shared<VGActor>();
        roundrect->SetPosition(600, 100);
        roundrect->SetSize(400, 400);
        roundrect->AddRect(20.0f);
        roundrect->SetFill(ColorI(255, 0, 0, 255));
        roundrect->SetStroke(ColorI(255, 255, 0, 255), 10);
        roundrect->Upload();
        WindowManager::Instance().Add(roundrect);

        ellipse = std::make_shared<VGActor>();
        ellipse->SetPosition(1100, 100);
        ellipse->SetSize(400, 400);
        ellipse->AddEllipse();
        ellipse->SetFill(ColorI(255, 0, 0, 255));
        ellipse->SetStroke(ColorI(255, 255, 0, 255), 20);
        ellipse->Upload();
        WindowManager::Instance().Add(ellipse);
    }

};

int main()
{
    VGActorSample app;
    app.SetBackgroundColor(1.0f, 1.0f, 1.0f, 1.0f);
    app.Run();
    return 0;
}
